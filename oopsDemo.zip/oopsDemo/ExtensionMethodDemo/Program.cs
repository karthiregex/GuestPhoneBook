﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodDemo
{
    public class Program
    {
        //Global Variable
        int number = 5;
        static void Main(string[] args)
        {

            int numar = 8;
            dynamic num3 = "HI";
            int[] intArr = new int[2];
            ClsPerson clsPerson ;

            //CallAgain:
            Console.WriteLine("Enter Number1 :");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Number2 :");
            int num2 = Convert.ToInt32(Console.ReadLine());

            
            try
            {
                int res = num1 / num2;
                Console.WriteLine("the result is " + res);
            }
            //intArr[0] = numar;
            //intArr[1] = num3;
            //intArr[2] = numar;

            //clsPerson.Name = "karthik";
            catch (DivideByZeroException dex)
            {
                Console.WriteLine(dex.Message);
            }
            catch (NullReferenceException nex)
            {
                Console.WriteLine(nex.Message);
                throw;
            }
            catch (IndexOutOfRangeException ioex)
            {
                Console.WriteLine(ioex.Message);
            }
            catch (ArrayTypeMismatchException arrEx)
            {
                Console.WriteLine(arrEx.Message);
            }
            catch (SystemException sex)
            {
                Console.WriteLine(sex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
                //Console.WriteLine("Error while divide the numbers, give another values");
                //goto CallAgain;
            }

            finally
            {
                Console.WriteLine("Application Completed");
            }
            Console.ReadKey();
            //Program program = new Program();
            //program.multTable();

            //ExtMethodSample extMethod = new ExtMethodSample();
            //extMethod.sentance = "Testing";
            //extMethod.sentance2 = "Working";

            //ExtMethodSample sample = new ExtMethodSample { sentance = "testing", sentance2 = "Working" };

            //string WordTest = "This is to understand Extensions and its working fine as expected";
            //int count = WordTest.WordCount();
            //Console.WriteLine("Count of Given String is :" + count);



            ////Anonymous Types
            //var person = new { Name = "John Doe", Age = 33, address = "", email = "", mobile = 8687575 };

            //Console.WriteLine("Person Name :" + person.Name);
            //Console.ReadKey();

        }

        public void multTable()
        {
            int number = 10;
            for (int cnt = 0; cnt < 16; cnt++)
            {
                Console.WriteLine(cnt + "* " + this.number + " = " + 1 * this.number);
                //  Console.ReadKey();
            }

        }
    }

    // Extension Method
    public static class Utility
    {
        public static int WordCount(this string sentence)
        {
            string[] splitedWords = sentence.Split(new char[] { ' ' });
            int length = splitedWords.Length;
            return length;
        }
    }

    class Student
    {
        int stduentid { get; set; }

        string stduentName { get; set; }
    }
}
