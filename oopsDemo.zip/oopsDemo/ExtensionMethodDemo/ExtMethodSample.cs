﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodDemo
{
    public class ExtMethodSample
    {
        public string sentance { get; set; }
        public string sentance2 { get; set; }
        public int getNumber()
        {
            return 0;
        }
        public int getNumber2()
        {
            return 0;
        }
        public int getNumber3()
        {
            return 0;
        }
        public int getNumber4()
        {
            return 0;
        }
        public int getNumber5()
        {
            return 0;
        }
    }

    public class ClsPerson
    {
        public string Name;

        public int Age = 0;
    }
}
