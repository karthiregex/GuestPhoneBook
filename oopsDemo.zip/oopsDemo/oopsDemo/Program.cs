﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EncapsulationDemo;
namespace oopsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomerDetails customer = new CustomerDetails();
            int numbers = 5;
            int WeekdayStart = (int)Days.Mon;
            int WeekdayEnd = (int)Days.Fri;

            Console.WriteLine("Monday: {0}", WeekdayStart);
            Console.WriteLine("Friday: {0}", WeekdayEnd);

           // Product. = 897;
            string res = Product.ProductMethod(numbers);

            Console.ReadKey();

            //DateTime dt = System.DateTime.Now;

            Product product = new Product();

            //Product product2 = new Product(dt);

            //Product product3 = new Product();
            //product.Number2

            //product[5];

            EmployeeOverload employeeOverload = new EmployeeOverload();
            employeeOverload.GetEmpNames();

            employeeOverload.GetEmpNames("Chennai");
        }
    }

    public enum Days
    {
        Sun,
        Mon,
        tue,
        Wed,
        thu,
        Fri,
        Sat
    }

    public class EmployeeOverload
    {
        public string[] GetEmpNames()
        {
            string[] names = { "kavi", "Bob", "Ram", "dhoni" };
            return names;
        }

        public string[] GetEmpNames(string location)
        {
            string[] names = { "Ram", "dhoni" };
            return names;
        }

        public string[] GetEmpNames(int pincode)
        {
            string[] names = { "Ram", "dhoni" };
            return names;
        }

        public string[] GetEmpNames(int dincode, int pincode)
        {
            string[] names = { "Ram", "dhoni" };
            return names;
        }
    }

    public class Product
    {
        //Variable or Fields
        public int number;
        private static int employeeId;
        public static string name;
        public static DateTime dateTime;

        //Property
        public int Number { get; set; }
        //Read only property
        public int Number2 { get; }
        //Write only property
        public int Number3 { set; get; }

        //public int EmployeeId
        //{
        //    get { return employeeId; }
        //    set { employeeId = value; }
        //}
        //public Product()
        //{
        //    number = 0;
        //    name = null;
        //    //0.00
        //    //date 01/01/1200
        //}

        //Constructor - Special Member function used to initialze the object
        //static Product()
        //{
        //    number = 100;
        //    name = "UserName";
        //    dateTime = System.DateTime.Now;
        //}

        public Product()
        {

        }

        public Product(DateTime dt)
        {

        }

        //Method
        public int ProductMethod(int[] arrInt)
        {
            return 0;
        }

        //overload operator
        public static string ProductMethod(int num)
        {
            num = num + num + num;  //+ == adding
            return "The final Result of my method is " + num; //+ concat
        }

        //destructors
        ~Product()
        {

        }
    }
}
