﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDEmo
{

    //Parent Class or Base Class
    public class ClsPdfCreation
    {
        public void CreatePdfDoc()
        {
            string str;
            ClsProduct output = new ClsProduct();
            using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream())
            {
                //Document document = new Document(PageSize.A4, 10, 10, 10, 10);

                //PdfWriter writer = PdfWriter.GetInstance(document, memoryStream);
                //document.Open();

                //Chunk chunk = new Chunk("This is from chunk. ");
                //document.Add(chunk);

            }
        }

        public void Printproduct()
        {
            //string Filepath = @"C:\Users\sdkca\Desktop\path-to-your-pdf\pdf-sample.pdf";
            //    Process printProcess = new Process();
            //    printProcess.StartInfo = printProcessInfo;
            //    printProcess.Start();
        }
    }

    public sealed class ClsPdfCreationSealed
    {
    }
}
