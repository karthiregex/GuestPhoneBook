﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EncapsulationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            BankAccount obj = new BankAccount();
            CustomerDetails customerDetails = new CustomerDetails();           
            obj.GetCustmerDetails();
        }
    }

    class BankAccount
    {

        public CustomerDetails GetCustmerDetails()
        {
            CustomerDetails customer = new CustomerDetails();

            customer.AccountNumber = 4548785454;
            customer.CustomerName = "PrivilageCustomer";
            //customer.AtmPin = 7895;

            return customer;
        }

    }


}
