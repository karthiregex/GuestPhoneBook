﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EncapsulationDemo
{
    public class CustomerDetails
    {
        public long AccountNumber { get; set; }
        public string CustomerName { get; set; }
        private int AtmPin { get; set; }

        public bool GetCash(long AccountNumber)
        {
            if(AccountNumber==777777)
            {
                if(AtmPin ==7856)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }
    }
}
