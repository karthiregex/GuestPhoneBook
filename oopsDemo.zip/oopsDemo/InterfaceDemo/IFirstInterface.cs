﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    public interface IFirstInterface
    {
        int AddNumbers(int number1, int number2);

        long multiNumbers(int number1, int number2);
    }

    public interface ISecondInterface
    {
        int subtractNumbers(int number1, int number2);

        long divNumbers(int number1, int number2);
    }
}
