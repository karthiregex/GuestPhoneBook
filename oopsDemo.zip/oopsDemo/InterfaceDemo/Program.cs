﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ClsMathOperations operations = new ClsMathOperations();
            int res = operations.AddNumbers(89, 87);
            Console.WriteLine(res);

            Console.WriteLine(operations.AddNumbers(89, 87));

            Console.WriteLine(operations.multiNumbers(87, 55));
        }
    }
}
