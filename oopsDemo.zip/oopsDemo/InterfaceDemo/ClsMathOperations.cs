﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    public class ClsMathOperations : IFirstInterface, ISecondInterface
    {
        public int AddNumbers(int number1, int number2)
        {
            return number1 + number2;
        }

        public long divNumbers(int number1, int number2)
        {
            return number1 / number2;
        }

        public long multiNumbers(int number1, int number2)
        {
            return number1 * number2;
        }

        public int subtractNumbers(int number1, int number2)
        {
            return number1 - number2;
        }
    }
}
