﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphisum
{
    public class StaticDemo
    {
        public int GetStudentId(string Name)
        {
            if (Name == "Sachin")
            {
                return 321;
            }
            else
            {
                return 654;
            }
        }

        public static int GetStudentId(string Name, string Location)
        {
            if (Name == "Sachin" && Location.Equals("Mumbai"))
            {
                return 321;
            }
            else
            {
                return 654;
            }
        }
    }
}
