﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphisum
{
    class Program
    {
        static void Main(string[] args)
        {
            //Normal Process
            StaticDemo obj = new StaticDemo();
            obj.GetStudentId("Sachin");

            //Static
            StaticDemo.GetStudentId("Sachin","Mumbai");

            CustomerDetails customer = new CustomerDetails();

            bool res = customer.GetCash("7777 7766 9999 7894");
            bool res2 = customer.GetCash(777777);
            bool res3 = customer.GetCash("7777 7766 9999 7894", 777777);
        }
    }

    public class CustomerDetails
    {
        public CustomerDetails()
        {

        }

        public CustomerDetails(int number)
        {

        }
        public CustomerDetails(string name)
        {

        }
        public long AccountNumber { get; set; }
        public string CustomerName { get; set; }
        private int AtmPin { get; set; }

        public bool GetCash(long AccountNumber)
        {
            if (AccountNumber == 777777)
            {
                if (AtmPin == 7856)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        public bool GetCash(string CardNumber)
        {
            if (CardNumber == "7777 7799 6666 4578")
            {
                if (AtmPin == 7856)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }
        public bool GetCash(string CardNumber, long AccountNumber)
        {
            if (CardNumber == "7777 7799 6666 4578" || AccountNumber == 777777)
            {
                if (AtmPin == 7856)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        public bool GetCash(decimal CardNumber)
        {
            if (CardNumber == 45454)
            {
                if (AtmPin == 7856)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }
    }
}
